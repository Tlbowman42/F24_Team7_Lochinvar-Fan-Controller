#ifndef EEPROM_H
#define EEPROM_H

#include "stm32l4xx_hal.h"
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <stdint.h>
extern SPI_HandleTypeDef hspi1;

// Commands for EEPROM
#define EEPROM_READ 	0x03		// Read data from EEPROM
#define EEPROM_WRITE 	0x02		// Write data to EEPROM
#define EEPROM_WREN 	0x06		// Set the write enable latch(enable write operation)
#define EEPROM_WRDI 	0x04		// Reset write enables latch (disable write operation)
#define EEPROM_RDSR 	0x05		// Read status register
#define EEPROM_WRSR 	0x01		// Write status register

void EEPROM_Init(void);
void EEPROM_Read(uint16_t address, uint8_t *data, uint16_t size);
void EEPROM_Write(uint16_t address, uint8_t *data, uint16_t size);
void EEPROM_WaitForWriteComplete(void);
uint8_t EEPROM_ReadStatus(void);

#endif
