#ifndef LCD_H
#define LCD_H
#include "stm32l4xx_hal.h"
#include <stdio.h>
#include <math.h>

/* LCD Command Definitions */
#define LCD_CMD_CLEAR_DISPLAY        0x01
#define LCD_CMD_RETURN_HOME          0x02
#define LCD_CMD_ENTRY_MODE_SET       0x06
#define LCD_CMD_DISPLAY_ON           0x0C
#define LCD_CMD_DISPLAY_OFF          0x08
#define LCD_CMD_FUNCTION_SET         0x38  // 8-bit mode, 2 lines, 5x8 dots
#define LCD_CMD_SET_CURSOR           0x80  // Base address for line 1

void LCD_Print(char *str);
void LCD_SetCursor(uint8_t row, uint8_t col);
void LCD_Init(void);
void LCD_SendData(uint8_t data);
void LCD_SendCommand(uint8_t cmd);
void LCD_Send8Bit(uint8_t data);
void blink(char *str,int line);
void menu_system(void);
#endif
