
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"
#include "lcd.h"
#include "eeprom.h"
#include "sd.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

#define BUTTON_UP_PIN     GPIO_PIN_4
#define BUTTON_DOWN_PIN   GPIO_PIN_5
#define BUTTON_LEFT_PIN   GPIO_PIN_6
#define BUTTON_RIGHT_PIN  GPIO_PIN_7
#define BUTTON_OK_PIN     GPIO_PIN_8
#define BUTTON_BACK_PIN   GPIO_PIN_9
#define BUTTON_PORT       GPIOC
// Buttons are connected to Port C

#define DEBOUNCE_MS 190  		// 190 ms debounce
#define TIM2_CLK 80000000UL
#define TIM1_CLK 1000000UL
#define SCALE (TIM2_CLK/TIM1_CLK)
#define SD_CS_Pin GPIO_PIN_4
#define SD_CS_GPIO_Port GPIOA
#define SD_SPI_HANDLE hspi2
//#define FAN_TIMEOUT_MS 50000


// Typedef for different fan modes
typedef enum {
    FAN_CONTROL,
	FAN_SIM,
	PASSTHROUGH,
    MENU
} SystemState;


typedef struct {
    volatile uint32_t max;      // RPM value
    volatile uint32_t min;      // RPM val
    volatile uint32_t TranInc;  // RPM factor
    volatile uint32_t TranDec;  // RPM factor
    volatile int32_t  PWMmin;   // Minimum PWM to start
    volatile int32_t  PWMcont;  // Continuous PWM value
    volatile bool     fan_on;   // Is the fan on?
    volatile int      PPR;
} fanSpec_t;

extern volatile uint32_t g_periodTicks;
extern volatile uint32_t g_highTicks;
extern volatile uint32_t g_lowTicks;
extern volatile double   g_dutyCycle;
extern volatile double   g_frequency;
extern volatile int      PPR;
extern volatile bool     updateFreq;
extern volatile bool     stopSim;
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern volatile SystemState systemState;
extern fanSpec_t f1;
extern volatile double simFanSpeed;
extern bool editVar;
extern bool zeroSub;
extern bool Fan_ON_OFF;
extern bool fanSimRun;
extern bool passthroughMode;
extern uint32_t rpmVal;
extern bool switchScreen;

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);
uint32_t fanSpeedToPWM(uint32_t, uint32_t);
uint32_t calculatePWMFrequency(uint32_t);
void setPWMFrequency(TIM_HandleTypeDef *htim, uint32_t);
void updatePWM(TIM_HandleTypeDef *htim, uint32_t);
//void setTachFrequency(TIM_HandleTypeDef *htim, float);
void change_param(TIM_HandleTypeDef *htim);
void printFanSimStats(void);
void Error_Handler(void);

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
