#ifndef SD_H
#define SD_H

#include "stm32l4xx_hal.h"
#include "main.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
extern SPI_HandleTypeDef hspi2;


// List of useful commands

// Initialization commands
#define CMD0 	(0x40 | 0x00)		// GO_IDLE_STATE 			(Reset card, enter SPI mode)
#define CMD1 	(0x40 | 0x01)		// SEND_OP_COND 			(Used for SDSC cards only, not SDHC/SDXC)
#define CMD8 	(0x40 | 0x08)		// SEND_IF_COND 			(Check voltage compatibility & SDHC/SDXC support)
#define	CMD55	(0x40 | 0x37)		// APP_CMD					(Prepares next command as an application-specific command)
#define	ACMD41	(0x40 | 0x29)		// SD_SEND_OP_COND			(Initialize card and exit idle state, used instead of CMD1 for SDHC/SDXC)
#define	CMD58	(0x40 | 0x3A)		// READ_OCR					(Read Operating Conditions Register to check voltage & card type)

// Read & Write commands
#define CMD16 	(0x40 | 0x10)		// SET_BLOCKLEN 			(Set block length, always 512 bytes for SDHC/SDXC)
#define CMD17 	(0x40 | 0x11)		// READ_SINGLE_BLOCK 		(Read one 512-byte block from the SD card)
#define CMD18 	(0x40 | 0x12)		// READ_MULTIPLE_BLOCK 		(Read multiple blocks for efficient bulk transfers)
#define	CMD24	(0x40 | 0x18)		// WRITE_BLOCK				(Write one 512-byte block to the SD card)
#define CMD25	(0x40 | 0x19)		// WRITE_MULTIPLE_BLOCK		(Write multiple blocks for efficient bulk writes)
#define	ACMD23	(0x40 | 0x17)		// SET_WR_BLK_ERASE_COUNT	(Pre-erase multiple blocks before writing for faster speed)

// Status & Control commands
#define CMD9 	(0x40 | 0x09)		// SEND_CSD					(Read Card-Specific Data, contains block/sector size info)
#define CMD10 	(0x40 | 0x0A)		// SEND_CID					(Read Card Identification register)
#define CMD12 	(0x40 | 0x0C)		// STOP_TRANSMISSION		(Stop reading multiple blocks when using CMD18)
#define CMD13	(0x40 | 0x0D)		// SEND_STATUS				(Check if the card is ready for the next operation)
#define CMD42	(0x40 | 0x2A)		// LOCK_UNLOCK				(Lock or unlock the SD card for security purposes)
#define CMD59	(0x40 | 0x3B)		// CRC_ON_OFF				(Enable/disable CRC checking, usually disabled in SPI mode)

// List of useful functions
void SD_init(void);
void SD_WriteBlock(uint32_t, uint8_t*);
void SD_ReadBlock(uint32_t, uint8_t*);
bool SD_VerifyWrite(uint32_t, uint8_t*);

#endif
