#include "lcd.h"
#include "main.h"
#include "fatfs.h"

// Declare external global button flags defined in main.c
extern volatile uint8_t buttonUpPressed;
extern volatile uint8_t buttonDownPressed;
extern volatile uint8_t buttonLeftPressed;
extern volatile uint8_t buttonRightPressed;
extern volatile uint8_t buttonOkPressed;
extern volatile uint8_t buttonBackPressed;
extern FRESULT save_f1_params(const char *filename, fanSpec_t *fan);
extern FRESULT load_f1_params(const char *filename, fanSpec_t *fan);

/* Send 8 Bits to LCD */
void LCD_Send8Bit(uint8_t data) {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, (data & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, (data & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, (data & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, (data & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, (data & 0x10) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, (data & 0x20) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, (data & 0x40) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, (data & 0x80) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);  // E High
    HAL_Delay(1);   // Small delay
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET);  // E Low
    HAL_Delay(1);   // Small delay after pulse
}

/* Send Command to LCD */
void LCD_SendCommand(uint8_t cmd) {
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET);  // RS Low for Command
    LCD_Send8Bit(cmd);  // Send full 8-bit command
    HAL_Delay(2);       // Command execution delay
}

/* Send Data (Character) to LCD */
void LCD_SendData(uint8_t data) {
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);  // RS High for Data
    LCD_Send8Bit(data);  // Send full 8-bit data
    HAL_Delay(2);        // Data write delay
}

/* Initialize LCD */
void LCD_Init(void) {
    HAL_Delay(50);  // Wait > 40ms after power on

    // Function Set: 8-bit, 2 lines, 5x8 dots
    LCD_SendCommand(0x38);
    HAL_Delay(5);

    // Display ON, Cursor ON, Blink ON
    LCD_SendCommand(0x0F);
    HAL_Delay(5);

    // Entry Mode: Increment cursor, no shift
    LCD_SendCommand(0x06);
    HAL_Delay(5);

    // Clear Display
    LCD_SendCommand(0x01);
    HAL_Delay(5);
}

/* Set Cursor Position */
void LCD_SetCursor(uint8_t row, uint8_t col) {
    uint8_t addr;
    switch (row % 4) {
        case 0: addr  = 0x80 + col; break;
        case 1: addr  = 0xC0 + col; break;
        case 2: addr  = 0x94 + col; break;
        case 3: addr  = 0xD4 + col; break;
        default: addr = 0x80 + col; break;
    }
    LCD_SendCommand(addr);
}

/* Print String on LCD */
void LCD_Print(char *str) {
    while (*str) {
        LCD_SendData(*str++);
    }
}

// causes text to blink on a given line
void blink(char *str,int line){
	char y[20] = "                    ";
	// sets cursor to start of a given line
	LCD_SetCursor(line,0);
	// Replaces given str with spaces
	LCD_Print(y);

	HAL_Delay(400);
	// resets cursor
	LCD_SetCursor(line,0);
	// Puts str back
	LCD_Print(str);
	HAL_Delay(400);
}


// menu code
void menu_system(void)
{
    // menu variables
    int stage = 0;
    int line  = 0;
    int holdNum = 0;
    int jump = 0;
    // user determined variables
    int user1[7] = {0,0,0,0,0,0,0};

    // Buffers to store formatted strings
    char maxFanSpeed[20];
    char minFanSpeed[20];
    char pwmRun[20];
    char pwmContinue[20];
    char ttfIncrease[20];
    char ttfDecrease[20];
    char pulsesPerRev[20];

    char *mode_base[] = {
        "Max FS    :%d",
        "Min FS    :%d",
        "PWM Run   :%d",
        "PWM Cont  :%d",
        "TTF In    :%d",
        "TTF De    :%d",
        "PPR       :%d"
    };

    // Format strings with integer values
    snprintf(maxFanSpeed,   sizeof(maxFanSpeed),   mode_base[0], user1[0]);
    snprintf(minFanSpeed,   sizeof(minFanSpeed),   mode_base[1], user1[1]);
    snprintf(pwmRun,        sizeof(pwmRun),        mode_base[2], user1[2]);
    snprintf(pwmContinue,   sizeof(pwmContinue),   mode_base[3], user1[3]);
    snprintf(ttfIncrease,   sizeof(ttfIncrease),   mode_base[4], user1[4]);
    snprintf(ttfDecrease,   sizeof(ttfDecrease),   mode_base[5], user1[5]);
    snprintf(pulsesPerRev,  sizeof(pulsesPerRev),  mode_base[6], user1[6]);

    // Create the mode1 menu with formatted strings
    char *mode1[] = {
        "Parameters: Mode 1",
        maxFanSpeed,
        minFanSpeed,
        pwmRun,
        pwmContinue,
        ttfIncrease,
        ttfDecrease,
        pulsesPerRev,
		"RUN",
		"SAVE",
		"LOAD",
		"Parameters: Mode 1"
    };

    // Start menu text
    char *start[4] = {
        "Hello, Choose Mode ",
        "Fan Sim            ",
        "Fan Drive          ",
        "Signal Passthrough "
    };

    // menu
    while(1)
    {
        switch (stage)
        {
        // ---------------------------------------------------------
        // CASE 0: Start Menu
        // ---------------------------------------------------------
        case 0:
        {
            line = 0;
            // Clear and print start menu
            LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
            HAL_Delay(100);
            for(int i = 0; i < 4; i++)
            {
                LCD_SetCursor(i,0);
                LCD_Print(start[i]);
            }
            line = 1;
            LCD_SetCursor(line,0);

            // Let user select a mode
            while(1)
            {
                if(buttonUpPressed && (line > 1))
                {
                    buttonUpPressed = 0;
                    line--;
                    LCD_SetCursor(line,0);
                }
                if(buttonDownPressed && (line < 3))
                {
                    buttonDownPressed = 0;
                    line++;
                    LCD_SetCursor(line,0);
                }
                if(buttonOkPressed)
                {
                    buttonOkPressed = 0;
                    stage = line;
                    break;
                }
                if(buttonBackPressed) buttonBackPressed = 0;
                HAL_Delay(50);
            }
            break;
        }

        // ---------------------------------------------------------
        // CASE 1: FAN SIM
        // ---------------------------------------------------------
        case 1:
        {
        	editVar   = false;
        	zeroSub   = false;
        	fanSimRun = false;
            line = 0;
            jump = 0;
            LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
            HAL_Delay(100);

            // Print first 4 lines
            for(; line < 4; line++)
            {
                LCD_SetCursor(line,0);
                LCD_Print(mode1[line]);
            }
            line = 1;
            LCD_SetCursor(line,0);

            while(1)
            {
            	if(jump == 1) break;
            	// Move up
                if(buttonUpPressed && (line > 1))
                {
                    buttonUpPressed = 0;
                    line--;
                    if(line == 3)
                    {
                        LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                        for(int i = 0; i < 4; i++)
                        {
                            LCD_SetCursor(i,0);
                            LCD_Print(mode1[i]);
                        }
                    }
                    if(line == 7)
                    {
                    	LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                    	for(int i = 4; i < 8; i++)
                    	{
                    		LCD_SetCursor(i,0);
                    		LCD_Print(mode1[i]);
                    	}
                    }
                    LCD_SetCursor(line,0);
                }
                // Move down
                if(buttonDownPressed && (line < 11))
                {
                    buttonDownPressed = 0;
                    line++;
                    if(line == 4)
                    {
                        LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                        for(int z = 4; z < 8; z++)
                        {
                            LCD_SetCursor(z,0);
                            LCD_Print(mode1[z]);
                        }
                    }
                    if(line == 8){
                    	LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                    	for(int z = 8; z < 12; z++){
                    		LCD_SetCursor(z,0);
                    		LCD_Print(mode1[z]);
                    	}
                    }
                    LCD_SetCursor(line,0);
                }

                if(buttonBackPressed){
                	buttonBackPressed = 0;
                	menu_system();
                }

                // If OK pressed at line==8 => finalize param entry
                if(buttonOkPressed && line == 8)
                {

                    buttonOkPressed = 0;

                    // Validate user1[] -> f1 fields

                    // Clamping the users min and continuous duty cycles
                    if(user1[2] > 100) user1[2] = 100;//user1[2] = user1[3] - 10;	// If min duty > 100 set LT cont duty
                    if(user1[3] > 100) user1[3] = 99;				// If cont duty > 100 clamp at 100
                    if(user1[2] <= 0) user1[3] = 2;		// If contduty < 0 clamp to 2
                    if(user1[3] <= 0) user1[2] = 1;		// If minduty < 0 clamp to 1
                    if(user1[2] < user1[2])				// If contduty < minduty swap
                    {
                        holdNum = user1[2];
                        user1[2] = user1[3];
                        user1[3] = holdNum;
                        holdNum = 0;
                    }


                    // Clamping the users max and min fan speeds
                    if(user1[0] < user1[1])
                    {
                        holdNum = user1[0];
                        user1[0] = user1[1];
                        user1[1] = holdNum;
                        holdNum = 0;
                    }
                    if(user1[0] > 25000) user1[0] = 25000;
                    if(user1[0] < 500)   user1[0] = 500;
                    if(user1[1] < 0)     user1[1] = 10;
                    if(user1[1] > 20000) user1[1] = 20000;

                    // Clamping the users transient increase and decreases
                    if(user1[4] <= 0) user1[4] = 50;
                    if(user1[5] <= 0) user1[5] = 50;
                    if(user1[4] > user1[0]) user1[4] = user1[0];
                    if(user1[5] > user1[0]) user1[5] = user1[0];

                    // Clamping PPR from 1->5
                    if(user1[6] > 5)  user1[6] = 5;
                    if(user1[6] <= 0) user1[6] = 1;

                    f1.max     = user1[0];
                    f1.min     = user1[1];
                    f1.PWMmin  = user1[2];
                    f1.PWMcont = user1[3];
                    f1.TranInc = user1[4];
                    f1.TranDec = user1[5];
                    f1.PPR     = user1[6];

                    // Switch to FAN_SIM mode
                    systemState = FAN_SIM;
                    fanSimRun = true;
                    LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                    HAL_Delay(50);

                    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);			// Starting output channel
                   	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);	// Setting output channel to 0
                   	HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_2);			// Starting input

                    while(1)
                    {
                    	change_param(&htim1);
                    	// Example LCD updates
                    	LCD_SetCursor(0,0);
                    	LCD_Print("FAN SIM ACTIVE");
                    	char buf[32];

                    	// show input duty cycle
                    	LCD_SetCursor(1,0);
                    	snprintf(buf,sizeof(buf),"Duty: %6.1f%%", g_dutyCycle);
                    	LCD_Print(buf);

                    	// show spool speed
                    	LCD_SetCursor(2,0);
                    	snprintf(buf,sizeof(buf),"SimSpd: %6.0f RPM", simFanSpeed);
                    	LCD_Print(buf);

                    	// show measured freq
                    	LCD_SetCursor(3,0);
                    	snprintf(buf,sizeof(buf),"Freq:  %7.1f Hz", g_frequency);
                    	LCD_Print(buf);

                    	// If user presses OK => exit spool
                    	if(buttonBackPressed)	//change to back button press
                    	{
                    		fanSimRun = false;
                    		buttonBackPressed = 0;
                            HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_2);
                    		HAL_TIM_IC_Stop_IT(&htim2, TIM_CHANNEL_2);

                    		// Clearing variables
                            g_frequency = 0;
                            g_dutyCycle = 0;
                            simFanSpeed = 0;
                    		menu_system();
                    		break;
                    	}
                    	HAL_Delay(200); // spool step
                    }
                }

                // If OK pressed otherwise => param editing
                if (buttonOkPressed)
                {
                	editVar = false;
                    buttonOkPressed = 0;
                    LCD_SetCursor(line, 11);
                    int num_out = 0;
                    int num_inc = 0;
                    if (user1[line-1] == 0){
                    	num_inc = 0;
                    }else{
                    	num_inc = log10(user1[line-1]);
                    }
                    if (line == 9){//save
                    	// Save the current fan parameters to the SD card
                    	f1.max     = user1[0];
                    	f1.min     = user1[1];
                    	f1.PWMmin  = user1[2];
                    	f1.PWMcont = user1[3];
                    	f1.TranInc = user1[4];
                    	f1.TranDec = user1[5];
                    	f1.PPR 	   = user1[6];

                    	FRESULT saveRes = save_f1_params("fanparam.txt", &f1);
                    	if (saveRes == FR_OK) {
                    		LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                    		LCD_SetCursor(1, 0);
                    		LCD_Print("Save Success!");
                    		HAL_Delay(2000);
                    		LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                    		stage = 1;
                    		jump = 1;

                    	} else {
                    		LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                    		LCD_SetCursor(1, 0);
                    		LCD_Print("Save Failed!");
                    		HAL_Delay(750);
                    		jump = 1;
                    		stage = 1;
                    	}

                    }else if (line == 10){//load
                    	// Clear the f1 structure before loading
                    	editVar = false;
                    	memset(&f1, 0, sizeof(f1));

                    	// Load the fan parameters from the SD card
                    	FRESULT loadRes = load_f1_params("fanparam.txt", &f1);
                    	if (loadRes == FR_OK) {
                    		LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                    		LCD_SetCursor(1, 0);
                    		LCD_Print("Load Success!");
                    		HAL_Delay(2500);
                    		// Update user1[] from loaded parameters
                    		user1[0] = f1.max;
                    		user1[1] = f1.min;
                    		user1[2] = f1.PWMmin;
                    		user1[3] = f1.PWMcont;
                    		user1[4] = f1.TranInc;
                    		user1[5] = f1.TranDec;
                    		user1[6] = f1.PPR;

                    		// Update the strings with the loaded values
                    		snprintf(maxFanSpeed,  sizeof(maxFanSpeed),  mode_base[0], user1[0]);
                    		snprintf(minFanSpeed,  sizeof(minFanSpeed),  mode_base[1], user1[1]);
                    		snprintf(pwmRun,       sizeof(pwmRun),       mode_base[2], user1[2]);
                    		snprintf(pwmContinue,  sizeof(pwmContinue),  mode_base[3], user1[3]);
                    		snprintf(ttfIncrease,  sizeof(ttfIncrease),  mode_base[4], user1[4]);
                    		snprintf(ttfDecrease,  sizeof(ttfDecrease),  mode_base[5], user1[5]);
                    		snprintf(pulsesPerRev, sizeof(pulsesPerRev), mode_base[6], user1[6]);

                    		stage = 1;
                    		jump = 1;
                    	} else {
                    		LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
                    		LCD_SetCursor(1, 0);
                    		LCD_Print("Load Failed!");
                    		HAL_Delay(750);
                    		jump = 1;
                    		stage = 1;
                    	}
                    }

                    while(num_out == 0)
                    {
                    	editVar = true;
                    	zeroSub = false;
                    	if (jump == 1) break;
                        if (buttonUpPressed)
                        {
                            buttonUpPressed = 0;
                            user1[line-1] = user1[line-1] + (int)pow(10,num_inc);
                            LCD_SetCursor(line,0);

                            if(user1[line-1] > 25000 && line == 1) user1[line-1] = 25000;				//works
                            if(user1[line-1] > 20000 && line == 2) user1[line-1] = 20000;				//works
                            if(line == 4 && user1[line-1] > 100) user1[line-1] = 100;					//works
                           // if(user1[line-1] > (user1[line] - 10) && line == 3) user1[line-1] = user1[line];
                            if(user1[line-1] > user1[0] && line == 5) user1[line-1] = user1[0];
                            if(user1[line-1] > user1[0] && line == 6) user1[line-1] = user1[0];
                            if(user1[line-1] > 5 && line == 7) user1[line-1] = 5;

                            snprintf(mode1[line], sizeof(maxFanSpeed), mode_base[line-1], user1[line-1]);
                            LCD_Print(mode1[line]);
                            LCD_SetCursor(line,(11 - num_inc + log10(user1[line-1])));
                        }
                        if (buttonDownPressed) {
                            if (user1[line-1] > 0) {
                                // Process valid decrement
                                buttonDownPressed = 0;
                                if (user1[line-1] - (int)pow(10, num_inc) <= 0) {
                                    zeroSub = true;
                                    user1[line-1] = 0;
                                    num_inc = 0;
                                    LCD_SetCursor(line,0);
                                    LCD_Print("                    ");
                                    LCD_SetCursor(line,0);
                                    snprintf(mode1[line], sizeof(maxFanSpeed), mode_base[line-1], 0);
                                    LCD_Print(mode1[line]);
                                    LCD_SetCursor(line,11);
                                } else {
                                    zeroSub = false;
                                    if (user1[line-1] > (int)pow(10, num_inc)) {
                                    	user1[line-1] -= (int)pow(10, num_inc);
                                    	num_inc = log10(user1[line-1]);
                                    }else{
                                    	user1[line-1] -= (int)pow(10, num_inc);
                                    }
                                    LCD_SetCursor(line,0);
                                    LCD_Print("                    ");
                                    LCD_SetCursor(line,0);
                                    snprintf(mode1[line], sizeof(maxFanSpeed), mode_base[line-1], user1[line-1]);
                                    LCD_Print(mode1[line]);
                                    LCD_SetCursor(line, (11 - num_inc + log10(user1[line-1])));
                                }
                            } else {
                                // If already 0, clear the flag so it doesn't affect later operations
                                buttonDownPressed = 0;
                            }
                        }
                        if(buttonBackPressed)
                        {
                            buttonBackPressed = 0;
                            LCD_SetCursor(line, 0);
                            num_out = 1;
                            editVar = false;
                        }
                        if(buttonLeftPressed)
                        {
                        	float temp_left;
                        	buttonLeftPressed = 0;
                        	num_inc++;
                        	if(num_inc > 4) num_inc = 4; // limit digits

                        	temp_left = user1[line-1] / (int)pow(10,num_inc - 1);
                        	if((user1[line-1] < (int)pow(10,num_inc)) && (1 <= temp_left) && (temp_left < 2)){
                        		user1[line-1] = user1[line-1] - (int)pow(10,num_inc - 1) + (int)pow(10,num_inc);
                        	}else if (user1[line-1] < (int)pow(10,num_inc)){
                        		user1[line-1] = user1[line-1]  + (int)pow(10,num_inc);
                        	}
                        	if(line == 4 && (int)pow(10,num_inc) > 100){
                        		user1[line-1] = 100;
                        		num_inc = 2;
                        	}
                            if(user1[line-1] > (user1[line-2] - 10)   && line == 3){
                            	user1[line-1] = user1[line] - 10;
                            	num_inc = 1;
                            	if(user1[line-1] < 0) user1[line-1] = 0;
                            }
                            if(user1[line-1] > 5 && line == 7){
                            	user1[line-1] = 5;
                            	num_inc = 0;
                            }
                        	LCD_SetCursor(line,0);
                        	LCD_Print("                    ");
                        	LCD_SetCursor(line,0);
                        	snprintf(mode1[line], sizeof(maxFanSpeed), mode_base[line-1], user1[line-1]);
                        	LCD_Print(mode1[line]);
                        	LCD_SetCursor(line,(11 - num_inc + log10(user1[line-1])));
                        }
                        if(buttonRightPressed && num_inc>0)
                        {
                        	buttonRightPressed = 0;
                        	num_inc--;
                        	LCD_SetCursor(line,0);
                        	snprintf(mode1[line], sizeof(maxFanSpeed), mode_base[line-1], user1[line-1]);
                        	LCD_Print(mode1[line]);
                        	LCD_SetCursor(line,(11 - num_inc + log10(user1[line-1])));
                        }
                        HAL_Delay(50);
                    }
                }
                HAL_Delay(50);
            } // end while(1) in case 1
            break;
        }
        case 2:
        {
        	menu_system();
        }

        // ---------------------------------------------------------
        // CASE 3: Signal passthrough
        // ---------------------------------------------------------
        case 3:
        {
            LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
            HAL_Delay(100);
            systemState = PASSTHROUGH;

            HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
            HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_2);

            while(1)
            {
                // Calculate RPM
            	if(!passthroughMode){
					rpmVal = (uint32_t)((g_frequency *60.0/(float)PPR));

					if(!switchScreen){
						LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
						switchScreen = !switchScreen;
					}

					// Print PPR
					LCD_SetCursor(0,0);
					char lcdBuff[32];
					snprintf(lcdBuff, sizeof(lcdBuff), "PPR: %i", PPR);
					LCD_Print(lcdBuff);

					// Print RPM
					LCD_SetCursor(1,0);
					snprintf(lcdBuff, sizeof(lcdBuff), "RPM: %6lu", rpmVal);
					LCD_Print(lcdBuff);

					// Print Freq
					LCD_SetCursor(2,0);
					snprintf(lcdBuff, sizeof(lcdBuff), "Freq: %4.0f Hz", g_frequency);
					LCD_Print(lcdBuff);

					// Print Duty
					LCD_SetCursor(3,0);
					snprintf(lcdBuff, sizeof(lcdBuff), "Duty: %4.1f%%", g_dutyCycle);
					LCD_Print(lcdBuff);

					// Handle Up/Down for PPR
					if(buttonUpPressed)
					{
						buttonUpPressed = 0;
						PPR++;
						if(PPR > 5) PPR = 5;
					}
					if(buttonDownPressed)
					{
						buttonDownPressed = 0;
						if(PPR > 1) PPR--;
					}
            	}
            	else{
					LCD_SetCursor(0,0);
					char lcdBuff[32];
					LCD_Print("PWM Mode");

					if(!switchScreen){
						LCD_SendCommand(LCD_CMD_CLEAR_DISPLAY);
						switchScreen = !switchScreen;
					}

					// Print Freq
					LCD_SetCursor(1,0);
					snprintf(lcdBuff, sizeof(lcdBuff), "Freq: %4.0f Hz", g_frequency);
					LCD_Print(lcdBuff);

					// Print Duty
					LCD_SetCursor(2,0);
					snprintf(lcdBuff, sizeof(lcdBuff), "Duty: %4.1f%%", g_dutyCycle);
					LCD_Print(lcdBuff);

					LCD_SetCursor(3,0);
                    LCD_Print("                    ");
            	}

                // If Back => exit back to start menu
                if(buttonBackPressed)
                {
                    buttonBackPressed = 0;
                    HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_2);
                    HAL_TIM_IC_Stop_IT(&htim2, TIM_CHANNEL_2);

                    // Resetting values
                    PPR = 2;
                    rpmVal = 0;
                    g_frequency = 0;
                    g_dutyCycle = 0;
                    stage = 0;  // Return to start

                    break;
                }
                HAL_Delay(200);
            }
            break;
        }

        } // end switch
    } // end while(1)
}
