#include "eeprom.h"

/*
 * Reads the status register from the EEPROM.
 * Returns the status byte.
 */
uint8_t EEPROM_ReadStatus(void){
    uint8_t command = EEPROM_RDSR;
    uint8_t status = 0;

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET);	// CS low
    HAL_SPI_Transmit(&hspi1, &command, 1, HAL_MAX_DELAY);   // Send RDSR command
    HAL_SPI_Receive(&hspi1, &status, 1, HAL_MAX_DELAY);     // Receive status
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);     // CS high

    return status;
}

/*
 * Polls the EEPROM status register until the write-in-progress (WIP) bit is cleared.
 */
void EEPROM_WaitForWriteComplete(void) {
    uint8_t status;
    do {
        status = EEPROM_ReadStatus();
        HAL_Delay(1);
    } while (status & 0x01); // Loop while WIP (bit 0) is set
}

/*
 * EEPROM initialization function that only sets the chip select high
 * as the HOLD and WP pins have been wired to VDD
 */
void EEPROM_Init(void){
    HAL_Delay(40);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);  // Setting the chip select high
}

/*
 * EEPROM read function that takes in address, data buffer, and size constraints.
 */
void EEPROM_Read(uint16_t address, uint8_t *buf, uint16_t size){
    uint8_t command[3] = {
        EEPROM_READ,
        (address >> 8) & 0xFF,
        address & 0xFF
    };

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET); 	// CS low
    HAL_SPI_Transmit(&hspi1, command, 3, HAL_MAX_DELAY);	// Send READ command and address
    HAL_SPI_Receive(&hspi1, buf, size, HAL_MAX_DELAY);     	// Receive data
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);     // CS high
}

/*
 * EEPROM write function that sends a data buffer alongside an address to write to the EEPROM.
 */
void EEPROM_Write(uint16_t address, uint8_t *data, uint16_t size){
    uint8_t wren = EEPROM_WREN;

    // Step 1: Enable write operations by sending the WREN command
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET);	// CS low
    HAL_SPI_Transmit(&hspi1, &wren, 1, HAL_MAX_DELAY);      // Send WREN command
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);     // CS high

    // Step 2: Send the WRITE command along with the address and data
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET);	// CS low again
    uint8_t command[3] = {
        EEPROM_WRITE,
        (address >> 8) & 0xFF,
        address & 0xFF
    };
    HAL_SPI_Transmit(&hspi1, command, 3, HAL_MAX_DELAY);	// Send WRITE command and address
    HAL_SPI_Transmit(&hspi1, data, size, HAL_MAX_DELAY);    // Send the data to be written
    HAL_Delay(5);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);     // CS high

    // Step 3: Poll the EEPROM to ensure the write cycle is complete
    EEPROM_WaitForWriteComplete();
}
