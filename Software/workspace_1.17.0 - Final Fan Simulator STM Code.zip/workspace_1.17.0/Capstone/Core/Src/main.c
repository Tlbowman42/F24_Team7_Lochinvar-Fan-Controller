#include "main.h"
#include "fatfs.h"

// Track last press times
static uint32_t lastUpPress   = 0;
static uint32_t lastDownPress = 0;
static uint32_t lastLeftPress = 0;
static uint32_t lastRightPress= 0;
static uint32_t lastOkPress   = 0;
static uint32_t lastBackPress = 0;

// Button Press Flags
volatile uint8_t buttonUpPressed = 0;
volatile uint8_t buttonDownPressed = 0;
volatile uint8_t buttonLeftPressed = 0;
volatile uint8_t buttonRightPressed = 0;
volatile uint8_t buttonOkPressed = 0;
volatile uint8_t buttonBackPressed = 0;

// Fan sim and passthrough variables
volatile uint32_t g_periodTicks = 0;		// Variable for total number of ticks calculations
volatile uint32_t g_highTicks   = 0;		// Variable for stroing high ticks on input channel
volatile uint32_t g_lowTicks    = 0;		// Variable for storing low ticks from input channel
volatile double    g_dutyCycle   = 0.0f;		// Calculated duty cycle from input channel
volatile double    g_frequency   = 0.0f;		// Calculated frequency from input channel
volatile int      PPR           = 2;		// Variable for Passthrough PPR
volatile bool     updateFreq    = false;	// Bool to update LCD
volatile bool     stopSim       = false;	// Bool to stop Fan_sim
volatile double   simFanSpeed           = 0.0f;		// Simulated fan speed in RPM
bool     editVar                = false;	// Bool stating if user is modulating a param
bool     zeroSub                = false;	// Bool stating if the user is subbing 0
bool     Fan_ON_OFF             = false;    // Bool stating if fan is on or off
int      countTime              = 0;
bool     fanSimRun              = false;
bool     passthroughMode        = false;	// Bool for passthrough signal, (false = tach || true = PWM)
uint32_t rpmVal                 = 0;
bool switchScreen               = false;

SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_SPI2_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
FRESULT save_f1_params(const char *filename, fanSpec_t *fan);	// Fan sim menu save function
FRESULT load_f1_params(const char *filename, fanSpec_t *fan);	// Fan sim load menu function

volatile SystemState systemState = MENU;	// State variables declaring what system we're in

// Fan_Sim variable struct
fanSpec_t f1 = {
    .max     = 0,
    .min     = 0,
    .TranInc = 0,
    .TranDec = 0,
    .PWMmin  = 0,
    .PWMcont = 0,
    .fan_on  = false,
	.PPR     = 2
};

int main(void) {

    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_SPI2_Init();
    MX_TIM1_Init();
    MX_TIM2_Init();
    MX_FATFS_Init();
    EEPROM_Init();
    LCD_Init();
    menu_system();

    while (1) {
    	if(updateFreq){
    		updateFreq = 0;
    	}
    }
}

// SD Card saving to file function
FRESULT save_f1_params(const char *filename, fanSpec_t *fan) {
    FIL fil;
    FRESULT res;
    UINT bytesWrote;
    char buffer[256];

    // Mount the SD card file system
    FATFS FatFs;
    res = f_mount(&FatFs, "", 1);
    if (res != FR_OK) {
        LCD_SetCursor(3, 0);
        LCD_Print("Mount Failed!");
        return res;
    }

    // Open the file for writing
    res = f_open(&fil, filename, FA_WRITE | FA_CREATE_ALWAYS);
    if (res != FR_OK) {
        LCD_SetCursor(3, 0);
        snprintf(buffer, sizeof(buffer), "Open Err: %d", res);
        LCD_Print(buffer);
        f_mount(NULL, "", 0);
        return res;
    }

    // Format the fan parameters into a text string
    snprintf(buffer, sizeof(buffer),
             "Fan Simulation User Parameters:\n"
             "-------------------------------\n"
             "max=%lu\n"
             "min=%lu\n"
             "TranInc=%lu\n"
             "TranDec=%lu\n"
             "PWMmin=%lu\n"
             "PWMcont=%lu\n"
             "fan_on=%d\n"
             "PPR=%d\n",
             fan->max,
             fan->min,
             fan->TranInc,
             fan->TranDec,
             fan->PWMmin,
             fan->PWMcont,
             fan->fan_on,
             fan->PPR);

    // Write the buffer to the file
    res = f_write(&fil, buffer, strlen(buffer), &bytesWrote);
    if (res != FR_OK || bytesWrote == 0) {
        LCD_SetCursor(3, 0);
        snprintf(buffer, sizeof(buffer), "Write Err: %d", res);
        LCD_Print(buffer);
        f_close(&fil);
        f_mount(NULL, "", 0);
        return res;
    }

    // Close the file and unmount
    f_close(&fil);
    f_mount(NULL, "", 0);
    return FR_OK;
}

// SD Card loading from file function
FRESULT load_f1_params(const char *filename, fanSpec_t *fan) {
    FIL fil;
    FRESULT res;
    UINT bytesRead;
    char buffer[256];

    // Mount the SD card file system
    FATFS FatFs;
    res = f_mount(&FatFs, "", 1);
    if (res != FR_OK) {
        LCD_SetCursor(3, 0);
        LCD_Print("Mount Failed!");
        return res;
    }

    // Open the file for reading
    res = f_open(&fil, filename, FA_READ);
    if (res != FR_OK) {
        LCD_SetCursor(3, 0);
        snprintf(buffer, sizeof(buffer), "Open Err: %d", res);
        LCD_Print(buffer);
        f_mount(NULL, "", 0);
        return res;
    }

    // Read data into buffer (leave room for null terminator)
    res = f_read(&fil, buffer, sizeof(buffer) - 1, &bytesRead);
    if (res != FR_OK || bytesRead == 0) {
        LCD_SetCursor(3, 0);
        snprintf(buffer, sizeof(buffer), "Read Err: %d", res);
        LCD_Print(buffer);
        f_close(&fil);
        f_mount(NULL, "", 0);
        return res;
    }

    // Null-terminate the buffer
    buffer[bytesRead] = '\0';

    // Temporary variable for fan_on since sscanf doesn't directly handle bool
    int fan_on_int = 0;

    // Skip the header lines
    char *dataStart = strstr(buffer, "max=");
    if (dataStart == NULL) {
        LCD_SetCursor(3, 0);
        LCD_Print("Data Not Found");
        f_close(&fil);
        f_mount(NULL, "", 0);
        return FR_DISK_ERR;
    }

    // Parse the string to populate your fan structure
    sscanf(dataStart,
           "max=%lu\n"
           "min=%lu\n"
           "TranInc=%lu\n"
           "TranDec=%lu\n"
           "PWMmin=%lu\n"
           "PWMcont=%lu\n"
           "fan_on=%d\n"
           "PPR=%d\n",
           &fan->max,
           &fan->min,
           &fan->TranInc,
           &fan->TranDec,
           &fan->PWMmin,
           &fan->PWMcont,
           &fan_on_int,
           &fan->PPR);

    fan->fan_on = (fan_on_int != 0);

    // Close the file and unmount
    f_close(&fil);
    f_mount(NULL, "", 0);
    return FR_OK;
}

// Could add a watchdog timer for measured input
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim){

    if (htim->Instance == TIM2 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2 && systemState == PASSTHROUGH)
    {
        // Capture the current timer count at this edge
        uint32_t thisCapture = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);

        // Toggle between expecting a rising edge and a falling edge.
        static uint8_t  expectingRising = 1;
        static uint32_t lastRising      = 0;  // store timer count of last rising edge capture

        if (expectingRising)
        {
            // ========== RISING EDGE DETECTED ==========
            static uint32_t prevRising = 0;

            // Measure full period from prevRising->thisRising
            if (thisCapture >= prevRising)
                g_periodTicks = thisCapture - prevRising;
            else
                g_periodTicks = (htim->Init.Period + 1 - prevRising) + thisCapture;

            prevRising  = thisCapture;
            lastRising  = thisCapture;

            // Switch to falling edge
            TIM2->CCER &= ~TIM_CCER_CC2P; // clear => default rising
            TIM2->CCER |=  TIM_CCER_CC2P; // set => falling
            expectingRising = 0;
        }
        else
        {
            // ========== FALLING EDGE DETECTED ==========
            // Measure high time from lastRising to thisFalling
            if (thisCapture >= lastRising)
                g_highTicks = thisCapture - lastRising;
            else
                g_highTicks = (htim->Init.Period + 1 - lastRising) + thisCapture;

            // Switch back to rising edge
            TIM2->CCER &= ~TIM_CCER_CC2P; // clear => rising
            expectingRising = 1;

            // We have g_periodTicks (full period) and g_highTicks (high portion)
            if (g_periodTicks > 0)
            {
                // Low portion = period - high
                if (g_highTicks <= g_periodTicks)
                    g_lowTicks = g_periodTicks - g_highTicks;
                else
                    g_lowTicks = 0;

                // Duty cycle = (high / period)*100
                g_dutyCycle = ((float)g_highTicks * 100.0f) / (float)g_periodTicks;

                if(g_dutyCycle > 100.0f) g_dutyCycle = 100.0f;
                else if(g_dutyCycle < 0.0f) g_dutyCycle = 0.0f;

                // frequency = TIM2_CLOCK / periodTicks
                // (Because TIM2 is at 80MHz => PSC=0)
                g_frequency = (float)TIM2_CLK / (float)g_periodTicks;

                // ========== REPLICATE ON TIM1 CHANNEL 2 ==========
                // TIM2 is 80MHz, but TIM1 is 1MHz meaning scale by /80
                if (g_periodTicks > 1)
                {
                    // Scale the period
                    uint32_t period80 = g_periodTicks;
                    // integer division by 80
                    uint32_t period1M = period80 / SCALE;
                    if (period1M > 0) period1M--; // replicate "period - 1"

                    // Scale the high portion
                    uint32_t high80 = g_highTicks;
                    uint32_t high1M = high80 / SCALE;
                    if (high1M > 0) high1M--;

                    // Edge case: if period1M is 0 i.e. extremely high freq then skip
                    if (period1M < 1)
                    {
                        __HAL_TIM_SET_AUTORELOAD(&htim1, 0);
                        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
                    }
                    else
                    {
                        // Ensure CCR <= ARR
                        if (high1M > period1M)
                            high1M = period1M;

                        // Write scaled values to TIM1
                        __HAL_TIM_SET_AUTORELOAD(&htim1, period1M);
                        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, high1M);

                        // Force update event => latch new ARR/CCR immediately
                        htim1.Instance->EGR = TIM_EGR_UG;
                        __HAL_TIM_SET_COUNTER(&htim1, 0);
                    }
                }
                else
                {
                    // period=1 => extremely high freq => set safe values
                    __HAL_TIM_SET_AUTORELOAD(&htim1, 0);
                    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
                }
            }
            else
            {
                // Invalid period => reset
                g_lowTicks  = 0;
                g_dutyCycle = 0.0f;
                g_frequency = 0.0f;
                __HAL_TIM_SET_AUTORELOAD(&htim1, 0);
                __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
            }
            // Notify main loop to update LCD or logic
            updateFreq = true;
        }
    }
    else if (htim->Instance == TIM2 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2 && systemState == FAN_SIM){
    	// This block ONLY measures the input PWM and stores it
        // in g_dutyCycle / g_frequency, without replicating it
        // onto TIM1. That way, you can do spool logic later.

        // Track rising/falling edges with static state:
    	static uint8_t  expectingRising = 1;
    	static uint32_t lastRising      = 0;
    	static uint32_t prevRising      = 0;

    	// Current capture
    	uint32_t thisCapture = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);

    	if (expectingRising)
    	{
    		// ========== RISING EDGE DETECTED ==========
    		if (thisCapture >= prevRising){
    			g_periodTicks = thisCapture - prevRising;
    		}
            else{
            	g_periodTicks = (htim->Init.Period + 1 - prevRising) + thisCapture;
            }

    		prevRising = thisCapture;
    		lastRising = thisCapture;

    		// Switch to falling
    		TIM2->CCER &= ~TIM_CCER_CC2P; // clear => rising
    		TIM2->CCER |=  TIM_CCER_CC2P; // set => falling
    		expectingRising = 0;
    	}
    	else
    	{
    		// ========== FALLING EDGE DETECTED ==========
    		if (thisCapture >= lastRising){
    			g_highTicks = thisCapture - lastRising;
    		}
            else{
            	g_highTicks = (htim->Init.Period + 1 - lastRising) + thisCapture;
            }

            // Switch back to rising
    		TIM2->CCER &= ~TIM_CCER_CC2P; // clear => rising
    		expectingRising = 1;

    		// Now we have g_periodTicks (full period) and g_highTicks (high portion)
    		if (g_periodTicks > 0)
    		{
    			// duty cycle
    			g_dutyCycle = ((float)g_highTicks * 100.0f) / (float)g_periodTicks;
    			// frequency
    			g_frequency = (float)TIM2_CLK / (float)g_periodTicks;
    		}
            else
            {
            	// invalid => set safe
            	g_dutyCycle = 0.0f;
            	g_frequency = 0.0f;
            }

    		// Notify main loop
    		updateFreq = true;
    	}
    }
}

/*
 * Interrupt that helps with IO inputs and state changes
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    uint32_t now = HAL_GetTick(); // Current system time in ms

    if (systemState == FAN_CONTROL) {
        // Example: spool down if OK pressed
        if (GPIO_Pin == BUTTON_OK_PIN) {
            // Debounce check
            if ((now - lastOkPress) > DEBOUNCE_MS) {
                lastOkPress = now; // update last press time
                //stop = true;
                buttonOkPressed = 0;
            }
        }
    }
    else if (systemState == FAN_SIM){
    	if (GPIO_Pin == BUTTON_OK_PIN && fanSimRun == false){
    	    if ((now - lastOkPress) > DEBOUNCE_MS){
    	    	lastOkPress = now;
    	    	systemState = MENU;
    	    	buttonOkPressed = 1;
    	    }
    	}
    	if (GPIO_Pin == BUTTON_BACK_PIN){
    		if ((now - lastBackPress) > DEBOUNCE_MS){
    			lastBackPress = now;
    			systemState = MENU;
    			buttonBackPressed = 1;
    		}
    	}
    }
    else if (systemState == PASSTHROUGH){
    	if (GPIO_Pin == BUTTON_OK_PIN){
    		if ((now - lastOkPress) > DEBOUNCE_MS){
    			lastOkPress = now;
    			passthroughMode = !passthroughMode;
    			switchScreen = !switchScreen;
    		}
    	}
    	else if (GPIO_Pin == BUTTON_DOWN_PIN) {
    		if ((now - lastDownPress) > DEBOUNCE_MS) {
    			lastDownPress = now;
    	        buttonDownPressed = 1; // This flag is what decrements PPR
    	    }
        }
        else if (GPIO_Pin == BUTTON_UP_PIN) {
            if ((now - lastUpPress) > DEBOUNCE_MS) {
                lastUpPress = now;
                buttonUpPressed = 1; // This flag increments PPR in printFanSimStats()
            }
        }
        else if (GPIO_Pin == BUTTON_BACK_PIN) {
        	if ((now - lastBackPress) > DEBOUNCE_MS) {
        		lastBackPress = now;
                systemState = MENU;
        		buttonBackPressed = 1; // This flag is what decrements PPR
        	}
        }
    }
    else if (systemState == MENU) {
        // In MENU mode, we check each button
        if (GPIO_Pin == BUTTON_UP_PIN) {
            if ((now - lastUpPress) > DEBOUNCE_MS) {
                lastUpPress = now;
                buttonUpPressed = 1;
            }
        }
        else if (GPIO_Pin == BUTTON_DOWN_PIN  && zeroSub == false) {
            if ((now - lastDownPress) > DEBOUNCE_MS) {
                lastDownPress = now;
                buttonDownPressed = 1;
            }
        }
        else if (GPIO_Pin == BUTTON_LEFT_PIN) {
            if ((now - lastLeftPress) > DEBOUNCE_MS) {
                lastLeftPress = now;
                buttonLeftPressed = 1;
            }
        }
        else if (GPIO_Pin == BUTTON_RIGHT_PIN) {
            if ((now - lastRightPress) > DEBOUNCE_MS) {
                lastRightPress = now;
                buttonRightPressed = 1;
            }
        }
        else if (GPIO_Pin == BUTTON_OK_PIN && editVar == false) {
            if ((now - lastOkPress) > DEBOUNCE_MS) {
                lastOkPress = now;
                buttonOkPressed = 1;
            }
        }
        else if (GPIO_Pin == BUTTON_BACK_PIN) {
            if ((now - lastBackPress) > DEBOUNCE_MS) {
                lastBackPress = now;
                buttonBackPressed = 1;
            }
        }
    }
}


/*
 * Main spool logic and tach frequency calculation function
 */
void change_param(TIM_HandleTypeDef *htim)
{
    // ———————— stall-detect init & update ————————
    static bool    _stallInit      = false;
    static double  lastSimSpeed;
    static uint32_t lastChangeTick;
    uint32_t now = HAL_GetTick();

    if (!_stallInit) {
        // first time in seed both values
        lastSimSpeed   = simFanSpeed;
        lastChangeTick = now;
        _stallInit     = true;
    }
    else if (simFanSpeed != lastSimSpeed) {
        lastSimSpeed   = simFanSpeed;
        lastChangeTick = now;
    }

    // If lack of frequency 0 the duty
    if (g_frequency < 1.0f){
        g_dutyCycle = 0.0f;
    }

    //--------------------------------------------------------------------
    // Read the measured duty cycle from your input capture (0..100%)
    //--------------------------------------------------------------------
    double incomingDuty = g_dutyCycle;  // from TIM2 input
    if (incomingDuty > 100.0f) incomingDuty = 100.0f;
    if (incomingDuty < 0.0f)   incomingDuty = 0.0f;   // safety clamp

    double targetSpeed = 0.0f; // Target fan rpm

    if (incomingDuty < f1.PWMmin && Fan_ON_OFF == false){
        // Below start threshold => fan is off => spool down to 0
        targetSpeed = 0.0f;
    }
    else if (incomingDuty >= f1.PWMmin && Fan_ON_OFF == false){
        // spool to calculated value
        double fraction = (incomingDuty - (double)f1.PWMcont)
                       / (100.0f - (double)f1.PWMcont);

        // clamp fraction in [0..1]
        if (fraction < 0.0f) fraction = 0.0f;
        if (fraction > 1.0f) fraction = 1.0f;

        // Map fraction => [f1.min to f1.max]
        targetSpeed = (double)f1.min + fraction * ((double)f1.max - (double)f1.min);
        Fan_ON_OFF = true;
    }
    else if (incomingDuty < f1.PWMcont && Fan_ON_OFF == true){
        // Below threshold win on
        targetSpeed = 0.0f;
        Fan_ON_OFF = false;
    }
    else{
        // Above PWMcont => scale from [PWMcont..100%] => [min..max]
        double fraction = (incomingDuty - (double)f1.PWMcont)
                       / (100.0f - (double)f1.PWMcont);

        // clamp fraction in [0..1]
        if (fraction < 0.0f) fraction = 0.0f;
        if (fraction > 1.0f) fraction = 1.0f;

        // Map fraction => [f1.min to f1.max]
        targetSpeed = (double)f1.min + fraction * ((double)f1.max - (double)f1.min);
    }

    // — override if stuck at same simFanSpeed for ≥5 s —
    if ((now - lastChangeTick) >= 7000U) {
        targetSpeed = 0.0;
        g_dutyCycle = 0;
        g_frequency = 0;
        Fan_ON_OFF  = false;
        _stallInit = false;
    }

    // Spool logic
    if (simFanSpeed < targetSpeed){
        simFanSpeed += (double)f1.TranInc;
        if (simFanSpeed > targetSpeed)
            simFanSpeed = targetSpeed;
    }
    else if (simFanSpeed > targetSpeed){
        simFanSpeed -= (double)f1.TranDec;
        if (simFanSpeed < targetSpeed)
            simFanSpeed = targetSpeed;
    }

    // Tach Hz calculation
    float tachHz = (simFanSpeed / 60.0f) * (float)f1.PPR;

    // ARR = (timer_clock / freq) - 1
    // Timer_clock is 1 MHz => 1,000,000 / freqHz - 1
    uint32_t arrVal = (uint32_t)( (float)TIM1_CLK / tachHz ) - 1;

    // Clamp the ARR within the 16-bit timer range (0..65535)
    if (arrVal < 1)    arrVal = 1;
    if (arrVal > 65535) arrVal = 65535;

    // For a ~50% duty, set CCR to half ARR
    uint32_t ccrVal = arrVal / 2;

    // Update the timer registers
    if(incomingDuty >= f1.PWMmin && Fan_ON_OFF == false){   // Start the fan on process
        __HAL_TIM_SET_AUTORELOAD(htim, arrVal);
        __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_2, ccrVal);
    }
    if(incomingDuty > f1.PWMcont && Fan_ON_OFF == true){   // spool the fan up
        __HAL_TIM_SET_AUTORELOAD(htim, arrVal);
        __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_2, ccrVal);
    }
    if(incomingDuty < f1.PWMcont && Fan_ON_OFF == false){  // Spool the fan down if turning off
        __HAL_TIM_SET_AUTORELOAD(htim, arrVal);
        __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_2, ccrVal);
    }
    if(simFanSpeed == 0){  // Turn the fan off after spooling down
        __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_2, 0);
    }

    // Reset the counter for clean start
    __HAL_TIM_SET_COUNTER(htim, 0);
}



/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 64;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 7;
  hspi2.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi2.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 79;	// Scaled to a 1 MHz clock
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM2; //change to 2 to reinvert
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;		//Everything says to change this to falling in order to invert the signal
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC10 PC11 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PC0 PC1 PC2 PC3 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA2 PA3 PA5 PA10
                           PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_5|GPIO_PIN_10
                          |GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : SD_CS_Pin */
  GPIO_InitStruct.Pin = SD_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SD_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PA6 PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PC4 PC5 PC6 PC7
                           PC8 PC9 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7
                          |GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 PB10
                           PB11 PB12 PB7 PB8
                           PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PD2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : PB4 PB5 PB6 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
