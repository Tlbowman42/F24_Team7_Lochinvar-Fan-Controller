#include "sd.h"


/*
 *
 * Function used for dynamically normalizing commands, used only in initialization
 *
 */
uint8_t SD_SendCommand(uint8_t cmd, uint32_t arg, uint8_t crc){
    uint8_t command[6];					// Command array
    uint8_t response = 0xFF;			// Fixed response value

    // Format the command frame
    command[0] = 0x40 | cmd;        	// Command byte
    command[1] = (arg >> 24) & 0xFF; 	// Argument byte 3 (MSB)
    command[2] = (arg >> 16) & 0xFF; 	// Argument byte 2
    command[3] = (arg >> 8) & 0xFF;  	// Argument byte 1
    command[4] = arg & 0xFF;         	// Argument byte 0 (LSB)
    command[5] = crc;                	// CRC (Only needed for CMD0 & CMD8)

    // Pull CS low to start SPI transaction
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
    HAL_Delay(1);

    // Send command
    HAL_SPI_Transmit(&hspi2, command, 6, HAL_MAX_DELAY);

    // Wait for a valid response (R1 response format)
    uint16_t timeout = 1000;		// Timeout variable
    while(timeout--){
        HAL_SPI_Receive(&hspi2, &response, 1, HAL_MAX_DELAY);
        if(!(response & 0x80))break;// Valid response
        if(timeout == 0) {
            printf("ERROR: Timeout waiting for SD card response!\n");
            return 0xFF; // Error
        }
    }

    // Pull CS high to end SPI transaction
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);

    return response; // Return SD card response
}


/*
 *
 * Initializaion function for SD card
 *
 */
void SD_Init(){
    uint8_t response;
    uint8_t strt_cmd[11];
    memset(strt_cmd, 0xFF, sizeof(strt_cmd)); // Fill array with 0xFF (dummy clocks)

    HAL_Delay(40); // Give SD card time to power up

    // Send 74+ clock pulses to set SPI mode
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
    HAL_Delay(1);
    HAL_SPI_Transmit(&hspi2, strt_cmd, 11, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
    HAL_Delay(1);

    // Send CMD0 (GO_IDLE_STATE)
    response = SD_SendCommand(0, 0x00000000, 0x95);
    if(response != 0x01){
        printf("ERROR: SD card failed to enter IDLE state!\n");
        return;
    }

    // Send CMD8 (SEND_IF_COND) to check SDHC/SDXC support
    response = SD_SendCommand(8, 0x000001AA, 0x87);
    if (response == 0x01) {
        printf("SD card supports CMD8: SDHC/SDXC detected.\n");
    } else if (response == 0x05) {
        printf("SD card does NOT support CMD8: Likely an SDSC card.\n");
    } else {
        printf("ERROR: SD card returned an invalid response to CMD8!\n");
        return;
    }

    // Wait for ACMD41 (SD_SEND_OP_COND) to complete with a timeout
    uint16_t timeout = 10000;  								// Prevent infinite loop
    do {
        SD_SendCommand(55, 0x00000000, 0x65);   			// CMD55 (prepare for ACMD)
        response = SD_SendCommand(41, 0x40000000, 0x77);   	// ACMD41 (initialize)
        timeout--;
        if (timeout == 0) {
            printf("ERROR: Timeout waiting for ACMD41!\n");
            return;
        }
    } while (response != 0x00);  							// Wait for ready

    // Read OCR (Operating Conditions Register)
    response = SD_SendCommand(58, 0x00000000, 0x00);
    if (response != 0x00) {
        printf("ERROR: Failed to read OCR!\n");
        return;
    }

    // Increase SPI Speed to ~20 MHz after initialization
    hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
    if (HAL_SPI_Init(&hspi2) != HAL_OK) {
        printf("ERROR: SPI re-initialization failed!\n");
        Error_Handler();
    }

    printf("✅ SD card initialized successfully!\n");
}



/*
 *
 * Write function for SD card, writes one block (512 bytes) of data (coud be changed to multi block
 *
 */
void SD_WriteBlock(uint32_t blockAddr, uint8_t *data) {
    uint8_t response;			// SD SPI response
    uint8_t cmd[6];				// Command array
    uint8_t startToken = 0xFE;  // Start token for writing

    // Pull CS low to start SPI transaction
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
    HAL_Delay(1);

    // Send CMD24 (WRITE_BLOCK) with block address
    cmd[0] = 0x40 | 24;                   	// CMD24
    cmd[1] = (blockAddr >> 24) & 0xFF;    	// Block address MSB
    cmd[2] = (blockAddr >> 16) & 0xFF;
    cmd[3] = (blockAddr >> 8) & 0xFF;
    cmd[4] = blockAddr & 0xFF;           	// Block address LSB
    cmd[5] = 0xFF;  						// Dummy CRC (ignored in SPI mode)

    HAL_SPI_Transmit(&hspi2, cmd, 6, HAL_MAX_DELAY);

    //  Wait for a response (should be 0x00 if ready)
    for(int i = 0; i < 8; i++){
        HAL_SPI_Receive(&hspi2, &response, 1, HAL_MAX_DELAY);
        if(response == 0x00) break; 						// Card is ready
    }
    if(response != 0x00){
        printf("ERROR: SD card is not ready for write!\n");
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
        return;
    }

    // Send start token (0xFE) to indicate data write
    HAL_SPI_Transmit(&hspi2, &startToken, 1, HAL_MAX_DELAY);

    // Write the 512-byte data block
    HAL_SPI_Transmit(&hspi2, data, 512, HAL_MAX_DELAY);

    // Send 2-byte dummy CRC
    uint8_t dummyCRC[2] = {0xFF, 0xFF};
    HAL_SPI_Transmit(&hspi2, dummyCRC, 2, HAL_MAX_DELAY);

    // Wait for data response token
    HAL_SPI_Receive(&hspi2, &response, 1, HAL_MAX_DELAY);
    if((response & 0x1F) != 0x05){ 						// 0x05 = Data accepted
        printf("ERROR: SD card write failed!\n");
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
        return;
    }

    // Wait until card is no longer busy (sending dummy clocks)
    uint16_t timeout = 1000;	// Timeout variable
    do{
        HAL_SPI_Receive(&hspi2, &response, 1, HAL_MAX_DELAY);

        timeout--;
        if(timeout == 0){	// Timeout condition
        	printf("ERROR: TIMEOUT SD card unable to get response! \n");
        	return;
        }
    }while(response == 0x00);

    // Pull CS high to end SPI transaction
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
}


/*
 *
 * Sd card read function that reads single address blocks (512 bytes)
 *
 */
void SD_ReadBlock(uint32_t blockAddr, uint8_t *buffer) {
    uint8_t response;	// SD SPI response
    uint8_t cmd[6];		// Command array

    // Pull CS low to start SPI transaction
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
    HAL_Delay(1);

    // Send CMD17 (READ_SINGLE_BLOCK) with block address
    cmd[0] = 0x40 | 17;                   	// CMD17
    cmd[1] = (blockAddr >> 24) & 0xFF;    	// Block address MSB
    cmd[2] = (blockAddr >> 16) & 0xFF;
    cmd[3] = (blockAddr >> 8) & 0xFF;
    cmd[4] = blockAddr & 0xFF;            	// Block address LSB
    cmd[5] = 0xFF;  						// Dummy CRC (ignored in SPI mode)

    HAL_SPI_Transmit(&hspi2, cmd, 6, HAL_MAX_DELAY);

    // Wait for a valid response (should be 0x00 if ready)
    for(int i = 0; i < 8; i++){
        HAL_SPI_Receive(&hspi2, &response, 1, HAL_MAX_DELAY);
        if(response == 0x00)break; // Card is ready
    }
    if(response != 0x00){
        printf("ERROR: SD card is not ready for read!\n");
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
        return;
    }

    // Wait for the start token (0xFE)
    uint16_t timeout = 1000;
    do{
        HAL_SPI_Receive(&hspi2, &response, 1, HAL_MAX_DELAY);

        timeout--;
        if(timeout == 0){	// Timeout condition
           	printf("ERROR: TIMEOUT SD card unable to get response! \n");
           	return;
        }
    }while(response != 0xFE);

    // Read the 512-byte data block
    HAL_SPI_Receive(&hspi2, buffer, 512, HAL_MAX_DELAY);

    // Read 2-byte CRC (ignored in SPI mode)
    uint8_t dummyCRC[2];
    HAL_SPI_Receive(&hspi2, dummyCRC, 2, HAL_MAX_DELAY);

    // Pull CS high to end SPI transaction
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
}


/*
 *
 * Bool function used for validating proper writing to specific addresses
 *
 */
bool SD_VerifyWrite(uint32_t blockAddr, uint8_t *originalData) {
    uint8_t readBuffer[512]; 				// Buffer for reading back data
    SD_ReadBlock(blockAddr, readBuffer); 	// Read back the block

    // Compare each byte
    for(int i = 0; i < 512; i++){
        if(readBuffer[i] != originalData[i]){
            printf("ERROR: Data mismatch at byte %d!\n", i);
            return false; // Data corruption detected
        }
    }

    printf("SD Write Verification SUCCESS!\n");
    return true; // Data is correct
}

